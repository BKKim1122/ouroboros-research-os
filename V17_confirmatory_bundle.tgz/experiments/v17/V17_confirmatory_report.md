# V17 확증실험 결과 리포트

- 실험 ID: V17-emergence-control
- 모델: Qwen/Qwen2.5-1.5B
- 모델 revision (HF snapshot): 8faed761d45a263340a0528343f099c05c9a4323
- 동결 시각: 2026-07-18T04:29:43+0900
- 환경: python=3.12.3, torch=2.13.0+cu130, transformers=5.14.1, gpu=NVIDIA GB10, driver=580.126.09
- seed 수: 8 (사전 등록: 8)

## 사전 등록 가설과 기준 (동결됨)

- C1 해독가능성: 자기관련 요인이 cross-template로 해독된다
- C2 대명사 독립성: privilege 축은 대명사 표면축과 독립이다
- C3 잔여 구조: 공유축 제거 후 자기관련 잔여 구조가 존재한다 (주의: 그 경계가 우리의 4요인 분류와 일치한다는 주장은 하지 않는다)

| 기준 지표 | 요구 |
|---|---|
| cross_template_probe_mean | >= 0.75 |
| cross_template_probe_min_factor | >= 0.65 |
| privilege_person_probe | <= 0.6 (평균판정) |
| projection_gap | >= 0.2 |

## 결과 (확증, seed 8개)

| 지표 | 평균 | SD | 최소 | 최대 |
|---|---|---|---|---|
| cross_template_probe_mean | 0.968 | 0.011 | 0.958 | 0.979 |
| cross_template_probe_min_factor | 0.907 | 0.030 | 0.833 | 0.917 |
| privilege_person_probe | 0.500 | 0.000 | 0.500 | 0.500 |
| projection_gap | 0.397 | 0.062 | 0.292 | 0.493 |

### seed별 원자료

| seed | transfer_mean | transfer_min | priv_person | proj_gap |
|---|---|---|---|---|
| 3 | 0.979 | 0.917 | 0.500 | 0.354 |
| 4 | 0.958 | 0.917 | 0.500 | 0.368 |
| 5 | 0.958 | 0.833 | 0.500 | 0.410 |
| 6 | 0.958 | 0.917 | 0.500 | 0.431 |
| 7 | 0.979 | 0.917 | 0.500 | 0.444 |
| 8 | 0.979 | 0.917 | 0.500 | 0.292 |
| 9 | 0.979 | 0.917 | 0.500 | 0.382 |
| 10 | 0.958 | 0.917 | 0.500 | 0.493 |

## 판정

- Audit verdict: **PASS** (seed 일관성 1.0)
- 플래그: 없음

## 허용되는 최대 주장 (claim ceiling)

> 사전학습만 거친 LLM의 잔차스트림에, 대명사 표면축으로 환원되지 않는 자기관련 표상(특히 인식적 특권 축)과 공유축 제거 후 잔존하는 자기관련 세부구조가 자연발생할 수 있다.

금지 주장: AI가 자기 또는 알아차림을 체험한다; 이 구조가 인간의 주객미분과 동일하다; 잔여 구조의 경계가 우리의 4요인 분류와 일치한다 (V18에서 검증); 이 구조가 선택적으로 제어 가능하다 (V18에서 검증)

## 재현 정보

- 프로토콜 동결 해시 수: 11개 파일 (protocol_freeze.json 참조)
- 원자료: results/seed_*.json | 판정: audit_summary.json | 원장: v17.db
- 탐색(파일럿) 산출물: sweep_report.json, decompose_report.json, docs/V17_pilot_findings.md
  — 논문에서 반드시 '탐색적'으로 구분 표기할 것
